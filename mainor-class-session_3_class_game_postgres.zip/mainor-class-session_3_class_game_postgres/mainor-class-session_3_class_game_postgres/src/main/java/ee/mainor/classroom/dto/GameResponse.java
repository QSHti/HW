package ee.mainor.classroom.dto;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
public class GameResponse {

    private String text;

}
